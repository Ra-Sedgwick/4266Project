$( function() {
    
    
    $( "#datepicker" ).datepicker();
    
    
} );